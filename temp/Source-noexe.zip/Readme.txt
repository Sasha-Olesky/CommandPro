SocketIO NodeJS - Group Chat Implementation Test
Coded/Developed By Aravind.V.S
www.aravindvs.com


Client
-------
Compiled In Visual Studio 2012 & Should work on Visual Studio 2012 Express
Uses SocketIO4Net Client by J.W Stott (http://socketio4net.codeplex.com/)
Icon file downloaded from iconspedia(http://www.iconspedia.com/icon/chat-icon-35643.html)


Server
------
Tested & works on NodeJS v0.8.16 v0.9 running on Windows 7 Ultimate 64Bit & Ubuntu Server 12.04.2 LTS

Thanks & Regards!
Aravind.V.S